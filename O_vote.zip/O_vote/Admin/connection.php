<?php
	
	$link = mysqli_connect("localhost","root", "") or die("Not connectd");
    mysqli_select_db($link,"vote");

?>
