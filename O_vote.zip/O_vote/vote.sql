-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2018 at 05:09 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vote`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbadministrators`
--

CREATE TABLE IF NOT EXISTS `tbadministrators` (
  `admin_id` int(5) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbadministrators`
--

INSERT INTO `tbadministrators` (`admin_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'Sajal', 'Debnath', 'sajal@gmail.com', '1234567');

-- --------------------------------------------------------

--
-- Table structure for table `tbcandidates`
--

CREATE TABLE IF NOT EXISTS `tbcandidates` (
  `candidate_id` int(5) NOT NULL,
  `candidate_name` varchar(45) NOT NULL,
  `candidate_position` varchar(45) NOT NULL,
  `candidate_cvotes` int(11) NOT NULL,
  `pic` varchar(10000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phn` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbcandidates`
--

INSERT INTO `tbcandidates` (`candidate_id`, `candidate_name`, `candidate_position`, `candidate_cvotes`, `pic`, `email`, `phn`) VALUES
(3, 'Badal Chandra', 'President', 12, 'images/nature4.jpg', 'badal.cse.1.bu@gmail.com', '01744567123'),
(4, 'Rajib Molla', 'President', 21, 'images/actor9.jpg', 'rajibm.12.bu@gmail.com', '01923456789'),
(6, 'A.B.M. Anas', 'Join-Secretary', 3, 'images/actor11.jpg', 'anas@gmail.com', '123456789'),
(8, 'Mokbul Hossine', 'Secretary', 7, 'images/actor7.jpg', 'mokbul@gmail.com', '1234567890-'),
(9, 'Fozlle Rabbi', 'Secretary', 47, 'images/actor5.jpg', 'fazllerabbi23@gmail.com', '01812345678'),
(10, 'Shabaz Miah Shovon', 'Treasurer', 2, 'images/actor3.jpg', 'shabazmia@gmail.com', '017345678834'),
(11, 'Shafiqul Islam Rakib ', 'Executive-members', 1, 'images/nature1.jpeg', 'safikul@gmail.com', '01923456789'),
(12, 'Joy Sarkar', 'Executive-members', 1, 'images/mr_cat.jpg', 'joy@gmail.com', '0188888888888'),
(13, 'Sagor Saha', 'Treasurer', 0, 'images/cat1.jpg', 'sagorshaha.1234@gmail.com', '01823456789'),
(14, 'Hafsa', 'Join-Secretary', 4, 'images/actress_h.jpg', 'hafsa.bu.13.18@gmail.com', '01723456789'),
(15, 'S.Pintu Sarker', 'Join-Secretary', 0, 'images/actor10.jpg', 'pintus.sker@gmail.com', '01234567890'),
(16, 'Vabatas Datta', 'Join-Secretary', 1, 'images/actor2.jpg', 'datta@gmail.com', '01923456789'),
(18, 'Raju Rostogi', 'President', 15, 'images/actor12.jpg', 'raju@gmail.com', '37459238745'),
(19, 'Abhishek Baschan', 'Vice-president', 4, 'images/nature3.jpg', 'abhi@tut.com', '01863752637'),
(22, 'Rahat Hossain Faisal', 'Vice-president', 3, 'images/C-PNG-Clipart.png', 'rahat@gmail.com', '1234567890'),
(23, 'Sadik Mia', 'Join-Secretary', 4, 'images/actor1.jpg', 'sadikmia@gmail.com', '01823456789'),
(25, 'Sadia Jahan Mou', 'Treasurer', 0, 'images/girl.jpg', 'sadia@gmail.com', '1234321234'),
(26, 'Farhan quarish', 'Executive-members', 23, 'images/nature2.jpg', 'farhen@gmail.com', '0192345678'),
(27, 'Jhon M.k', 'Executive-members', 12, 'images/index.jpg', 'jhon@gmail.com', '0172345678'),
(28, 'Farhan Dz', 'Executive-members', 23, 'images/ctor17.jpg', 'fharhan@gmail.com', '01987765653'),
(29, 'M.D. Matin', 'Executive-members', 12, 'images/actor15.jpg', 'matin@gmail.com', '018345678988');

-- --------------------------------------------------------

--
-- Table structure for table `tbmembers`
--

CREATE TABLE IF NOT EXISTS `tbmembers` (
  `member_id` int(5) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `complete_vote` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbmembers`
--

INSERT INTO `tbmembers` (`member_id`, `first_name`, `last_name`, `email`, `password`, `complete_vote`) VALUES
(1, 'Sajal', 'DEBNATH', 'sajal@gmail.com', '12345', 0),
(2, 'Nadira ', 'Akther', 'nadira@gmail.com', '1234567', 0),
(3, 'Nazia', 'Hasnin', 'tammee@gmail.com', '1234567', 0),
(4, 'A.B.M.', 'Anas', 'anas@gmail.com', '1234567', 0),
(5, 'Sajib', 'Paul', 'sajib@gmail.com', '12345', 0),
(6, 'Protap', 'Biswas', 'protap@gmail.com', '12345', 0),
(7, 'Protap', 'Biswas', 'protap@gmail.com', '12345', 0),
(9, 'Imran', 'Gazi', 'imran@gmail.com', '12345', 0),
(10, 'Mahabuba', 'Morsona ', 'morsona@gmail.com', '12345', 0),
(11, 'Tanjum', 'Taju', 'taju@gmail.com', '1234', 0),
(12, 'Roy', 'Hridoy', 'roy@gmail.com', '12345', 0),
(13, 'sajal', 'debnath', 'sajaldebnath02@gmail.com', '12345', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbpositions`
--

CREATE TABLE IF NOT EXISTS `tbpositions` (
  `position_id` int(5) NOT NULL,
  `position_name` varchar(45) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpositions`
--

INSERT INTO `tbpositions` (`position_id`, `position_name`) VALUES
(1, 'Chairperson'),
(2, 'Secretary'),
(5, 'Vice-Secretary'),
(7, 'Organizing-Secretary'),
(8, 'Treasurer'),
(9, 'Vice-Treasurer'),
(10, 'Vice-Chairperson'),
(12, 'Head Of Dept');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbadministrators`
--
ALTER TABLE `tbadministrators`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbcandidates`
--
ALTER TABLE `tbcandidates`
  ADD PRIMARY KEY (`candidate_id`);

--
-- Indexes for table `tbmembers`
--
ALTER TABLE `tbmembers`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `tbpositions`
--
ALTER TABLE `tbpositions`
  ADD PRIMARY KEY (`position_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbadministrators`
--
ALTER TABLE `tbadministrators`
  MODIFY `admin_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbcandidates`
--
ALTER TABLE `tbcandidates`
  MODIFY `candidate_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `tbmembers`
--
ALTER TABLE `tbmembers`
  MODIFY `member_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbpositions`
--
ALTER TABLE `tbpositions`
  MODIFY `position_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
