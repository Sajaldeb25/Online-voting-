<?php
	session_start();
	require('connection.php');
	//echo' '.$_SESSION['member_id'].' ';
	
	$u_id = $_SESSION['member_id'];
	
	if(empty($_SESSION['member_id'])){
		header("location:home.php");
	} 
	//echo"$u_id</br>";
	$msg = "";
	$name = "";
	
	$sql="SELECT * FROM voter WHERE v_id ='$u_id'" or die(mysqli_error());
	$result=mysqli_query($link,$sql) ;
	
	$count=mysqli_num_rows($result);
	
	if($count==1)
	{
		//echo "sajal";
		$user = mysqli_fetch_assoc($result);
		$complete = $user['complete_vote'];
		//echo' '.$user['member_id'].' ';
		//echo" $complete";
		$name = $user['username'] ;
		
		//header("location:homenext.php");
		
		if($complete == "1")
			$msg = "Already you have completed your vote successfully.";
	}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home page </title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/login.css" rel="stylesheet">
    <link href="assets/css/news.css" rel="stylesheet">

  </head>
  <body>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/login.js"></script>
    
    <div class="container-fluid">
        <h1 style="text-align: center; font-weight: 700; font-size: 60px; ">Online Voting System</h1> </br>
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-black sticky-top">
    <a class="navbar-brand"><img src="logo.jpg" style="height: 43px; width: 70px;" ></a>
   <ul class="navbar-nav " style="padding-left: 700px">
    
    <li class="nav-item">
      <a class="nav-link" href="homenext.php">Home</a>
    </li>   
       
    <li class="nav-item" style="padding-left: 14px">
        <a href="candidate.php" class="nav-link" >Candidates</a>
    </li>
	
	<li class="nav-item" style="padding-left: 14px">
        <a href="vote.php" class="nav-link" >Vote</a>
    </li>
	
	<li class="nav-item" style="padding-left: 14px">
        <a href="result.php" class="nav-link" >Vote Result</a>
    </li>
	
	<li class="nav-item" style="padding-left: 14px">
        <a href="aboutus.php" class="nav-link" >About Us</a>
    </li>
	
    <li class="nav-item" style="padding-left: 14px">
        <a href="logout.php" class="nav-link" >Log Out</a>
    </li>
  </ul>
</nav>


<div style="padding-left:960px;">Welcome <?php echo" $name"; echo", $msg ";?></div>
<div style="padding-left:200px; padding-top:20px; font-size:20px; height:30px; width:400px; ">Latest Website Activity </div>

<div class="news shadow">
	<div style=" margin: 30px; width: 80% ; text-align:left ; padding-top: 18px; font-size:1em;">
		Hosted By <span style="color:green;">Admin</span> on June 29th, 2018.
		<p style=" margin: 15px; color: rgb(119,119,119) ; font-size: 1em ; font-style:italic ;"> Last Updated on June 28th, 2018.</p>
		
	</div>

<h3>Meghalaya Legislative Assembly election, 2018</h3><hr>
<P style=" margin: 30px; font-size:1em;">The Meghalaya Legislative Assembly election was held on 27th June, 2018 to elect 17of 30 members to the Meghalaya Legislative Assembly, with the result to be declared on that day.  The scheduled election in Williamnagar constituency...</p>
<a href="news1.php" >Read More</a>
</div>


<div class="news shadow">
	<div style=" margin: 30px; width: 80% ; text-align:left ; padding-top: 18px; font-size:1em;">
		Hosted By <span style="color:green;">Association</span> on January 18th, 2018.
		<p style=" margin: 15px; color: rgb(119,119,119) ; font-size: 1em ; font-style:italic ;"> Last Updated on June 28th, 2018.</p>
		
	</div>

<h3>Headline</h3>
<a href="">Read More</a>
</div>

<div class="news shadow">
	<div style=" margin: 30px; width: 80% ; text-align:left ; padding-top: 18px; font-size:1em;">
		Hosted By <span style="color:green;">Association</span> on January 18th, 2018.
		<p style=" margin: 15px; color: rgb(119,119,119) ; font-size: 1em ; font-style:italic ;"> Last Updated on June 28th, 2018.</p>
		
	</div>

<h3>Headline</h3>
<a href="">Read More</a>
</div>

  
    
  </body>
</html>