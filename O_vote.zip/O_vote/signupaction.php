<?php

	session_start();
	require('connection.php');
	
	$name = $_POST['username'];
	$pass = $_POST['pass'];
	$email = $_POST['email'];

	echo"$name</br>";
	echo"$pass</br>";
	echo"$email</br>";

	$sql="Insert into voter (username,password,email,complete_vote) VALUES('$name','$pass','$email','0')" or die(mysqli_error());
	$result=mysqli_query($link,$sql) ;
	echo"$result</br>";

	$count=mysqli_num_rows($result);

	header("location:home.php");


?>