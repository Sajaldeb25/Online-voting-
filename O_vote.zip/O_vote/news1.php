<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Home page</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

	<link href="assets/css/mdb.min.css" rel="stylesheet">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="assets/css/style.css" rel="stylesheet">
	<link href="assets/css/news.css" rel="stylesheet">

  </head>
  <body>

    
    <div class="container-fluid">
        <h1 style="text-align: center; font-weight: 700; font-size: 60px; ">Online Voting System</h1> <br>
</div>

<nav class="navbar navbar-expand-sm bg-dark navbar-black sticky-top">
    <a class="navbar-brand"><img src="logo.jpg" style="height: 43px; width: 70px;" ></a>
   <ul class="navbar-nav " style="padding-left: 1040px">   
       
  </ul>
</nav>

<!--Start of News part-->

	<div style="padding-left:200px; padding-top:20px; font-size:20px; height:30px; width:600px; "> </div>

	<div class="news shadow" style="height:1500px;">
		<div style=" margin: 30px; width: 80% ; text-align:left ; padding-top: 18px; font-size:1em;">
			Hosted By <span style="color:green;">Admin</span> on June 29th, 2018.
			<p style=" margin: 15px; color: rgb(119,119,119) ; font-size: 1em ; font-style:italic ;"> Last Updated on June 28th, 2018.</p>
			
		</div>

	<h3>Meghalaya Legislative Assembly election, 2018</h3><hr>
	<P style=" margin: 30px; font-size:17px; text-align:justify;">The <b>Meghalaya Legislative Assembly</b> election was held on 27th June, 2018 to elect 17of 30 members to the Meghalaya Legislative Assembly, with the result to be declared on that day.  The scheduled election in Williamnagar constituency 
	  was delayed to an undetermined date following the death of Nationalist Congress Party candidate Jonathone Sangma in an IED blast in East Garo Hills district on February 18, 2018. The incumbent Indian National Congress government, led by Chief Minister Mukul Sangma
	  attempted to win a re-election for the third time in a row. Here is the summary:</p>
	  <h4 style="text-align:center">Result of vote</h4>
	  
	  
	</div>




<!--End of News part-->


    
  
    
  </body>
</html>