<?php
	session_start();
	require('connection.php');


	$code=$_POST['code'];
	echo"$code";

	$code = mysql_real_escape_string($code);

	$sql="SELECT * FROM tbmembers WHERE password='$code' " or die(mysqli_error());
	$result=mysqli_query($link,$sql) ;
	

	$count=mysqli_num_rows($result);
	

	if($count==1)
	{
		//echo "sajal";
		$user = mysqli_fetch_assoc($result);
		//$_SESSION['member_id'] = $user['member_id'];
		//echo' '.$user['member_id'].' ';
		echo' '.$_SESSION['member_id'].' ';
		
		//header("location:homenext.php");
	}
			
	else
	{
		echo "Wrong Code";
		$msg = "You are providing wrong code."
	}

?>